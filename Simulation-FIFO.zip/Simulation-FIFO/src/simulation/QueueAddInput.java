 package simulation;

import java.util.Random;
import static simulation.Start.numinputtask;
 import static simulation.Start.policy;
import static simulation.Start.queues;

/**
 *
 * @author DANI
 * simula a entrada de novas tarefas
 */ 

public class QueueAddInput {

    
    public static void queueaddinput() {
     
        Random rad = new Random(); 
//        numinputtask = rad.nextInt(numinstance) + 1;

 
            for (int i = 0; i < numinputtask; i++) {
                //Adiciona "numinstance" tarefas 1 para queues[0] (queuefifo) 
                if ("FIFO".equals(policy)){
                    queues[0].add(1);
                    }
                //Adiciona "numinstance" tarefas 1 para queues[1] (queueRR1)
                else{  
                    queues[1].add(1);   
                    }
            }
    }      
}